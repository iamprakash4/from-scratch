const mongoose = require("mongoose");

const device = mongoose.model(
  "Device",
  new mongoose.Schema({
    user_id: String,
    name: String,
    devType: String,
    currentState: String,
    accessUserList: { type : Array , "default" : [] },
    lastUpdate: Date,
  })
);

module.exports = device;
