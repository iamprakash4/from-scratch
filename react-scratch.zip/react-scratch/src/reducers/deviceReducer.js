import { GET_DEVICE_LIST, 
  ADD_DEVICE,
  UPDATE_DEVICE,
  DELETE_DEVICE,
  SHARE_DEVICE,
  STATE_DEVICE,
  GET_EMAIL_LIST } from '../actions/types';
import isEmpty from '../validation/is-empty';

const initialState ={ 
  deviceList :[], 
  deviceAdd :{},  
  deviceUpdate :{},
  deviceDelete :{},
  deviceState:{},
  deviceShare:{},
  emailList:{}
};


export default function(state = initialState, action) {
  const data = action.payload
  switch (action.type) {
    case GET_DEVICE_LIST:
      
      return {
        ...state,
        deviceList: data
      };
      case UPDATE_DEVICE :
        return {
          ...state,
          deviceUpdate: data
        };
        case ADD_DEVICE :
        return {
          ...state,
          deviceAdd: data
        };
        case DELETE_DEVICE :
          return {
            ...state,
            deviceDelete: data
          };
          case SHARE_DEVICE :
          return {
            ...state,
            deviceShare: data
          };
          case STATE_DEVICE :
            return {
              ...state,
              deviceState: data
            };
          case GET_EMAIL_LIST :
          return {
            ...state,
            emailList: data
          };

    default:
      return state;
  }
}
