import axios from 'axios';
import { GET_ERRORS, SET_CURRENT_USER } from './types';
import setAuthToken from '../setAuthToken';
import jwt_decode from 'jwt-decode';

const CONFIG = 'http://localhost:8060/api/'

export const registerUser = (user, history) => dispatch => {
  const{email,password} = user;
  const username = user.name;
  axios
    .post(CONFIG +'auth/signup', {username,email,password})
    .then(res => history.push('/login'))
    .catch(err => {
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data,
      });
    });
};

export const loginUser = user => dispatch => {
  axios
    .post(CONFIG +'auth/signin', user)
    .then(res => {
      console.log('resres', res)
      const { accessToken } = res.data;
      localStorage.setItem('accessToken', accessToken);
      setAuthToken(accessToken);
      const decoded = jwt_decode(accessToken);
      dispatch(setCurrentUser(decoded));
    })
    .catch(err => {
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data,
      });
    });
};

export const setCurrentUser = decoded => {
  return {
    type: SET_CURRENT_USER,
    payload: decoded,
  };
};

export const logoutUser = history => dispatch => {
  localStorage.removeItem('jwtToken');
  setAuthToken(false);
  dispatch(setCurrentUser({}));
  history.push('/login');
};
