import axios from 'axios';
import { GET_ERRORS,
   GET_DEVICE_LIST
  ,ADD_DEVICE,
  UPDATE_DEVICE,
  DELETE_DEVICE,
  SHARE_DEVICE,
  STATE_DEVICE,
  GET_EMAIL_LIST } from './types';

const CONFIG = 'http://localhost:8060/api/'


export const deviceGet = () => dispatch => {
  axios
    .get(CONFIG +'device/read',)
    .then(res => {
      const  data  = res.data;
      dispatch({
        type: GET_DEVICE_LIST,
        payload: data,
      });
    })
    .catch(err => {
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data,
      });
    });
};

export const deviceAdd = (data) => dispatch => {
axios
  .post(CONFIG +'device/create',data)
  .then(res => {
    const  data  = res.data;
    dispatch({
      type: ADD_DEVICE,
      payload: data,
    });
  })
  .catch(err => {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  });
};

export const deviceUpdate = (data) => dispatch => {
axios
  .put(CONFIG +'device/edit',data)
  .then(res => {
    const  data  = res.data;
    dispatch({
      type: UPDATE_DEVICE,
      payload: data,
    });
  })
  .catch(err => {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  });
};

export const deviceDelete = (data) => dispatch => {
axios
  .delete(CONFIG +'device/delete',{data})
  .then(res => {
    const  data  = res.data;
    dispatch({
      type: DELETE_DEVICE,
      payload: data,
    });
  })
  .catch(err => {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  });
};

export const deviceShare = (data) => dispatch => {
axios
  .put(CONFIG +'device/share',data)
  .then(res => {
    dispatch({
      type: SHARE_DEVICE,
      payload: data,
    });
  })
  .catch(err => {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  });
};
export const deviceState = (data) => dispatch => {
axios
  .put(CONFIG +'device/currentState',data)
  .then(res => {
    const  data  = res.data;
    dispatch({
      type: STATE_DEVICE,
      payload: data,
    });
  })
  .catch(err => {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  });
};
export const getEmailList = () => dispatch => {
axios
  .get(CONFIG +'device/emailList',)
  .then(res => {
    const  data  = res.data;
    dispatch({
      type: GET_EMAIL_LIST,
      payload: data,
    });
  })
  .catch(err => {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  });
};